#!/bin/bash
#set -x

source ./lib/conf.sh

function destoryDevice(){
    odlAccessPoint=$(getConf "odl.accessPoint")
    odlAccessPwd=$(getConf "odl.accessPwd")

    requestURI="http://${odlAccessPwd}@${odlAccessPoint}/$1"
    curl -I -X DELETE "${requestURI}"
}

#simIP=$(getConf "sim.ip")
simIP=$(uname -a | awk '{print $2}')

#listorPorts=`cat ${} | awk -F: '{print $2}'`

#listorPorts=$(netstat -l -p --numeric-ports | grep $(ps -ef --width 900 | grep java | grep testtool | awk '{print $2}') | awk '{print $4}' | awk -F: '{print $2}')

#for port in ${listorPorts}
#do
#  deviceName="exa-sim-${simIP}(${port})"
#   destoryDevice "restconf/config/network-topology:network-topology/topology/topology-netconf/node/controller-config/yang-ext:mount/config:modules/module/odl-sal-netconf-connector-cfg:sal-netconf-connector/${deviceName}"
#done

pid=`ps -ef --width 900 | grep java | grep testtool | awk '{print $2}'`
kill -9 ${pid}
