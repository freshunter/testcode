#!/bin/bash
source ./lib/conf.sh

# call usage: findDevice ${deviceIp} ${devicePort}
function findDevice(){
    deviceIP=$1
    devicePort=$2
    deviceName="exa-sim-${deviceIP}(${devicePort})"

    cp ./conf/deviceFind.json temp.xml

    sed -in "s/{deviceName}/${deviceName}/g" temp.xml
    sed -in "s/{deviceIP}/${deviceIP}/g" temp.xml
    sed -in "s/{devicePort}/${devicePort}/g" temp.xml

    deviceFindReq=`cat ./temp.xml`
    echo "Finding device -> ${deviceName} "

    # @see
    # simluatorConf.ini -> section:odl -> item:accessPoint
    odlAccessPoint=$(getConf "odl.accessPoint")
    odlAccessPwd=$(getConf "odl.accessPwd")
    #deviceFindURI="http://${odlAccessPwd}@${odlAccessPoint}/restconf/config/opendaylight-inventory:nodes/node/controller-config/yang-ext:mount/config:modules"
    deviceFindURI="http://${odlAccessPwd}@${odlAccessPoint}/restconf/operations/exatopo:exatopo"

    #echo ${deviceFindReq}
    #echo ${deviceFindURI}
    curl --header "Content-Type:application/json" -d "${deviceFindReq}" "${deviceFindURI}"

    rm -rf temp.xml*
}


function rqcFindDevice(){
    deviceIP=$1
    devicePort=$2
    deviceName="exa-sim-${deviceIP}(${devicePort})"

    #response=$(java -jar ./lib/sender.jar cmssim40 "${deviceIP}" "${devicePort}" admin admin $3)
    #java -jar ./lib/sender.jar cmssim40 "${deviceIP}" "${devicePort}" admin admin $3 10

    odlAccessIP=$(echo "$(getConf "odl.accessPoint")" | awk -F: '{print $1}')
    odlAccessPwd=$(getConf "odl.accessPwd")
    odlAccessName=$(echo ${odlAccessPwd} | awk -F: '{print $1}')
    odlAccessPassword=$(echo ${odlAccessPwd} | awk -F: '{print $2}')

    java -jar ./lib/sender.jar ${odlAccessIP} "${deviceIP}" "${devicePort}" ${odlAccessName} ${odlAccessPassword} $3 10

    #echo "${response}" >> regist.result.log

    #ifSuccess=$(echo ${response} | grep "create_success")
    #if [[ "x${ifSuccess}" != "x" ]]
    #then
    #    echo "regist ${deviceName} success" >> regist.result.log
    #else
    #    echo "regist ${deviceName} failed" >> regist.result.log
    #fi
    #echo "success count: $(cat regist.result.log | grep success | wc)"
}

