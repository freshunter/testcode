#!/bin/bash

#set -x

source ./lib/conf.sh
source ./lib/findDevice.sh

JAVA_OPTS="-Xmx1G -XX:MaxPermSize=256M -Dorg.apache.sshd.registerBouncyCastle=false"
#SIMULAR_JAR="/home/Applications/.m2/repository/org/opendaylight/controller/netconf-testtool/0.2.8-Helium-SR3/netconf-testtool-0.2.8-Helium-SR3-executable.jar"
#SIMULAR_JAR="/root/.m2/repository/org/opendaylight/controller/netconf-testtool/0.2.8-Helium-SR3/netconf-testtool-0.2.8-Helium-SR3-executable.jar"
SIMULAR_JAR="./lib/netconf-testtool-0.3.0-20150410.023803-720-executable.jar"

rm -rf ./log/simulator.log

schemaPath=$(getConf "schema.path")
startPort=$(getConf "sim.startPort")
simCount=$(getConf "sim.count")

echo "use schemaPath -> ${schemaPath}"
echo "simulator count -> ${simCount}"

#java ${JAVA_OPTS} -jar ${SIMULAR_JAR} --starting-port ${startPort} --devices-count $1 --schemas-dir "${schemaPath}" --ssh false >> ./log/simulator.log &
java ${JAVA_OPTS}  -jar ${SIMULAR_JAR} --starting-port ${startPort} --device-count ${simCount} --schemas-dir "${schemaPath}"  >> ./log/simulator.log &

#loop wait simulator startup.
sleep 5
echo "simulator running..."

#simIP=$(getConf "sim.ip")
simIP=$(uname -a | awk '{print $2}')
endPort=$[$simCount + ${startPort} - 1]

for port in $(seq ${startPort} ${endPort})
do
    #echo "${simIP}->${port}"
    findDevice ${simIP} ${port} > /dev/null
done
