#!/bin/bash

#set -x

source ./lib/conf.sh

function queryInterfaceByName(){
    odlAccessPoint=$(getConf "odl.accessPoint")
    odlAccessPwd=$(getConf "odl.accessPwd")

    #http://cmssim40:8181/restconf/config/opendaylight-inventory:nodes/node/exa-sim-cmssim29(18730)/yang-ext:mount/exa-base:config/interface/ethernet/g1/
    requestURI="http://${odlAccessPwd}@${odlAccessPoint}/restconf/config/opendaylight-inventory:nodes/node/${1}/yang-ext:mount/exa-base:config/profile/bandwidth-profile/kkk/meter-mef/"
    curl --header "Content-Type:application/json" "${requestURI}" &
    #wget "${requestURI}"
    
}


function postInterface(){
    odlAccessPoint=$(getConf "odl.accessPoint")
    odlAccessPwd=$(getConf "odl.accessPwd")

    #req='{"exa-base:ethernet": [ { "port": "g1","description": "STBBox", "duplex": "full", "service-role": [ { "role": "uni","service": [{"service-name": "EXAVideo25","igmp:igmp": {"multicast-profile": "NO_MVR"},"shutdown": false,"match-list": "MatchUntagged"}]}],"shutdown": false,"speed": "100Mbs"}]}'
    req='{"exa-base:bandwidth-profile": [{"bandwidth-profile-name": "kkk","bandwidth-profile-type": "meter-mef","cir": 128}]}'

    requestURI="http://${odlAccessPwd}@${odlAccessPoint}/restconf/config/opendaylight-inventory:nodes/node/${1}/yang-ext:mount/exa-base:config/profile/"
    curl --header "Content-Type:application/json" -d "${req}" "${requestURI}" & 
}

#simIP=$(getConf "sim.ip")
simIP=$(uname -a | awk '{print $2}')
simCount=$(getConf "sim.count")
startPort=$(getConf "sim.startPort")
endPort=$[$simCount + ${startPort} - 1]

#listorPorts=$(netstat -l -p --numeric-ports | grep $(ps -ef --width 900 | grep java | grep testtool | awk '{print $2}') | awk '{print $4}' | awk -F: '{print $2}')


for port in $(seq ${startPort} ${endPort})
do
    deviceName="exa-sim-${simIP}(${port})"
    postInterface ${deviceName}
done

for var in $(seq 1 500)
do
    for port in $(seq ${startPort} ${endPort})
    do
        deviceName="exa-sim-${simIP}(${port})"
        queryInterfaceByName "${deviceName}"  
    done
    #sleep 2
done
