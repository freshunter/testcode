#!/bin/bash

set -x

source ./lib/conf.sh

failedCount=0
succCount=0

function queryInterfaceByName(){
    odlAccessPoint=$(getConf "odl.accessPoint")
    odlAccessPwd=$(getConf "odl.accessPwd")

    requestURI="http://${odlAccessPwd}@${odlAccessPoint}/restconf/config/opendaylight-inventory:nodes/node/${1}/yang-ext:mount/exa-base:config/interface/ethernet/${2}"
    response=$(curl --header "Content-Type:application/json" "${requestURI}")

    ifContain=$(echo ${response} | grep "EXAVideo25")

    if [[ "x${ifContain}" != "x"  ]]
    then
        #echo "result->ok" >> result.log
        succCount=$[${succCount} + 1]
    else
        #echo "result->failed" >> result.log
        failedCount=$[${failedCount} + 1]
    fi

    #echo "${1}: total:$[${succCount} + ${failedCount}]    succ:${succCount}    failed:${failedCount}" >> result.log
}

function batchQueryInterfaceByName(){
    for var in $(seq 1 $2)
    do
        queryInterfaceByName $1 "g1"
    done

    echo "${1}: total:$[${succCount} + ${failedCount}]    succ:${succCount}    failed:${failedCount}" >> result.log
}


function postInterface(){
    odlAccessPoint=$(getConf "odl.accessPoint")
    odlAccessPwd=$(getConf "odl.accessPwd")

    req='{"exa-base:ethernet": [ { "port": "g1","description": "STBBox", "duplex": "full", "service-role": [ { "role": "uni","service": [{"service-name": "EXAVideo25","igmp:igmp": {"multicast-profile": "NO_MVR"},"shutdown": false,"match-list": "MatchUntagged"}]}],"shutdown": false,"speed": "100Mbs"}]}'

    requestURI="http://${odlAccessPwd}@${odlAccessPoint}/restconf/config/opendaylight-inventory:nodes/node/${1}/yang-ext:mount/exa-base:config/interface/"
    curl --header "Content-Type:application/json" -d "${req}" "${requestURI}" &
}

#simIP=$(getConf "sim.ip")
simIP=$(uname -a | awk '{print $2}')
simCount=$(getConf "sim.count")
startPort=$(getConf "sim.startPort")
endPort=$[$simCount + ${startPort} - 1]

#listorPorts=$(netstat -l -p --numeric-ports | grep $(ps -ef --width 900 | grep java | grep testtool | awk '{print $2}') | awk '{print $4}' | awk -F: '{print $2}')


for port in $(seq ${startPort} ${endPort})
do
    deviceName="exa-sim-${simIP}(${port})"
    postInterface ${deviceName}
done

for port in $(seq ${startPort} ${endPort})
do
    deviceName="exa-sim-${simIP}(${port})"
    batchQueryInterfaceByName ${deviceName} $1 &
done

#totleReq=$(wc result.log | awk '{print $1}')
#failedCount=$(cat result.log | grep fail | wc |awk '{print $1}')
#succCount=$(cat result.log | grep ok | wc |awk '{print $1}')

